package com.sp.world.events.level1;

import com.sp.entity.custom.SkinWalkerEntity;
import com.sp.init.BackroomsLevels;
import com.sp.init.ModEntities;
import com.sp.init.ModSounds;
import com.sp.world.events.AbstractEvent;
import com.sp.world.levels.BackroomsLevelWithLights;
import com.sp.world.levels.custom.Level1BackroomsLevel;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

import java.util.List;

public class Level1Blackout extends AbstractEvent {
    private int skinWalkerSpawnDelay = 80;

    @Override
    public void init(World world) {
        if (!((BackroomsLevels.getLevel(world).orElse(BackroomsLevels.OVERWORLD_REPRESENTING_BACKROOMS_LEVEL)) instanceof Level1BackroomsLevel level)) {
            return;
        }

        if(level.getLightState() != BackroomsLevelWithLights.LightState.BLACKOUT) {
            level.setLightState(BackroomsLevelWithLights.LightState.BLACKOUT);
            playSound(world, ModSounds.LIGHTS_OUT);
        }
    }

    @Override
    public void ticks(int ticks, World world) {
        if (world.getRegistryKey() != BackroomsLevels.LEVEL1_WORLD_KEY) {
            return;
        }

        Random random = Random.create();

        List<? extends PlayerEntity> playerList = world.getPlayers();

        this.skinWalkerSpawnDelay--;

        if (this.skinWalkerSpawnDelay >= 0) {
            return;
        }
        for (PlayerEntity player : playerList) {
            int rand = player.getRandom().nextBetween(1, 10);

            if (rand != 1) {
                continue;
            }

            if (!world.getEntitiesByClass(SkinWalkerEntity.class, player.getBoundingBox().expand(32.0), SkinWalkerEntity::isAlive).isEmpty()) {
                continue;
            }

            SkinWalkerEntity skinWalker = ModEntities.SKIN_WALKER_ENTITY.create(world);

            if (skinWalker == null) {
                continue;
            }

            BlockPos.Mutable mutable = new BlockPos.Mutable();
            float randomAngle = random.nextFloat() * 360.0f;
            Vec3d spawnPos = new Vec3d(0, 0, 15).rotateY(randomAngle).add(player.getPos());
            if (!world.getBlockState(mutable.set(spawnPos.x, spawnPos.y, spawnPos.z)).blocksMovement()) {
                skinWalker.refreshPositionAndAngles(Math.floor(spawnPos.x) + 0.5f, spawnPos.y, Math.floor(spawnPos.z) + 0.5f, player.getYaw(), player.getPitch());
                world.spawnEntity(skinWalker);
                skinWalker.component.setTargetPlayerUUID(player.getUuid());
                skinWalker.component.setBeginReveal(true);
                this.skinWalkerSpawnDelay = 160;
            }
        }
    }

    @Override
    public void finish(World world) {
        super.finish(world);

        if (!((BackroomsLevels.getLevel(world).orElse(BackroomsLevels.OVERWORLD_REPRESENTING_BACKROOMS_LEVEL)) instanceof Level1BackroomsLevel level)) {
            return;
        }

        level.setLightState(BackroomsLevelWithLights.LightState.ON);
        playSound(world, ModSounds.LIGHTS_ON);
    }


    @Override
    public int duration() {
        return 600;
    }
}
